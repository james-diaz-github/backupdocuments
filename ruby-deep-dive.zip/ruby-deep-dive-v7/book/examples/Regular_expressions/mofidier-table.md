
{n} -> exactly n
?   -> 0 or 1
*   -> 0 or more
+   -> 1 or more
