
str.gsub(/\w+/) { |w| w.capitalize }
