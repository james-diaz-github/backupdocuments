
"foo\nbar".match(/^bar/)  # <MatchData "bar">
"foo\nbar".match(/\Abar/) # nil
