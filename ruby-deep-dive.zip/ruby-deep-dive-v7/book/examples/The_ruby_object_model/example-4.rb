
Array.ancestors
# [Array, Enumerable, Object, Kernel, BasicObject]
