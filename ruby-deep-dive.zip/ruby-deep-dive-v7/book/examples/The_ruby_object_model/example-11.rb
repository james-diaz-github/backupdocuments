
# The worst way to create a string!
Fixnum::Class::Object::String.new("testing")

# warning: toplevel constant Class referenced by Fixnum::Class
# warning: toplevel constant Object referenced by Class::Object
