
class Animal
  def self.test
  end
end

p Animal.singleton_methods
# What's the output?
