
"abcde".[](1)
