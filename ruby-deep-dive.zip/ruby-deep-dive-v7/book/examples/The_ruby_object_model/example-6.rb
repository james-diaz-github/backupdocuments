
Array.singleton_class
# => #<Class:Array>
