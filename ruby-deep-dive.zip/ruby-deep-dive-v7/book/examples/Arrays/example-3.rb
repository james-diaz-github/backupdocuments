
# Same effect as the last example, but faster to type
users = %w(john david peter)
