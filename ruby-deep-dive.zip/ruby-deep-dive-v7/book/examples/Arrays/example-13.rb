
users = users.map { |user| user.capitalize }
