
# These do the same thing
users.concat(new_users)  # Faster, because it works in-place
users += new_users
