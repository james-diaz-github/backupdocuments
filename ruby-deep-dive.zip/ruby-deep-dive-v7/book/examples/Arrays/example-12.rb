
users.each { |item| puts item }
