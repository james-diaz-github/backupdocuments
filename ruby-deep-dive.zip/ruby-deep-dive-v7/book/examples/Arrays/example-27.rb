
a = [1,2,3]
b = [2,4,5]

a & b
# Output: [2]
