
numbers = *1,2,3
