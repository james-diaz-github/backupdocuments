
last_user = users.pop # Removes the last element from the array and returns it
user.delete_at(0)     # Removes the element at index 0
