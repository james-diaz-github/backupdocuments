
class Abc
  def to_a
    puts "method called"
    [1,2,3,4,5]
  end
end

a = Abc.new
