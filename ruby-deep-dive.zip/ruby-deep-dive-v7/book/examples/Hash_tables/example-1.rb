
# Create a hash
h = { water: 300, oil: 100 }

# Print each key / value pair
h.each { |key, value| puts "The key is #{key} with value #{value}" }
