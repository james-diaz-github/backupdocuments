
h = { name: 'David', age: 28 }

h.key?(:name)
# => true

h.key?(:country)
# => false
