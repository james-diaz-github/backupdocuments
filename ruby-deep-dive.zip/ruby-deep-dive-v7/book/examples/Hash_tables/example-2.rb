
h = { name: 'John', age: 30 }

h.keys
# => [:name, :age]

h.values
# => ["John", 30]
