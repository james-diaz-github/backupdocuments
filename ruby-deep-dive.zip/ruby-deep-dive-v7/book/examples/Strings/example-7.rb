
puts "Please type your name: "
name = gets.chomp
# "Jesus"
