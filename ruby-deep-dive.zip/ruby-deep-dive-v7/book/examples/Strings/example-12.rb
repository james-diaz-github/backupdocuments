
str = "My cat is black"
str[0] = ""

puts str
# Output: "y cat is black"
