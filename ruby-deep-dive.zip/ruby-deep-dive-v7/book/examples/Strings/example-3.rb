
min_age = 18
puts "Sorry, you need to be #{min_age} or older to enter."
