
"The cake is a lie".gsub(/\w+/) { |word| word.capitalize }
