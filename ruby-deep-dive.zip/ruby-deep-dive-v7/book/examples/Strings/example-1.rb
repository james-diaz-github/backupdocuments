
first_name  = "Peter"
second_name = "Cooper"

first_name + " " + second_name
