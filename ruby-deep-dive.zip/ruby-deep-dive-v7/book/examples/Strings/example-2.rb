
animal = "cat"
puts "Hello, nice #{animal} you have there!"
