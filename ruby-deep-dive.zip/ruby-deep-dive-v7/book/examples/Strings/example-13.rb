
str.freeze
str[0] = ""

# RuntimeError: can't modify frozen String
