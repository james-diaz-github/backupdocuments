
"Many words".chars
# => ["M", "a", "n", "y", " ", "w", "o", "r", "d", "s"]
