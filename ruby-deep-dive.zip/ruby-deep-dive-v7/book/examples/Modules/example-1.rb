
module Numbers
  PI = 3.141592
end
