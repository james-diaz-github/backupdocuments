
Tiger.ancestors
=> [Life, Tiger, Animal, Object, Kernel, BasicObject]
