
say_something = -> { puts "This is a lambda" }
