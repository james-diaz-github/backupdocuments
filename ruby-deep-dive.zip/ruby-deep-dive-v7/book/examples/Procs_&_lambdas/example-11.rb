
times_two = ->(x) { x * 2 }
p times_two.call(10)
