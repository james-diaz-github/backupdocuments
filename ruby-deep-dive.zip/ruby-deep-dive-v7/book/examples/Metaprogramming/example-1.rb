
# This is equivalent to: puts "Hello"
send(:puts, "Hello")
