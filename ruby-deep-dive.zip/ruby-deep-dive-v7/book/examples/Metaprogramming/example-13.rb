
my_proc = method(:puts)
[5,10,20].each(&my_proc)
