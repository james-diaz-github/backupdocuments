
pt.send(:internal_method)
# => "Only for internal use"
