
String.instance_methods.size
# 172
