
Mail.deliver do
  from    "jesus_castello@blackbytes.info"
  to      "example@example.com"
  subject "Welcome"
  body    "Hi there! Welcome to my newsletter."
end
