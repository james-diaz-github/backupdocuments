
class PrivateTesting
  private

  def internal_method
    "Only for internal use"
  end
end
