
[5,10,20].each { |n| puts n }
