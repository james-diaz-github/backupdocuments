
class Vote < ActiveRecord::Base
end
