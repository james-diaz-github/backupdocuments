
begin
  puts "test"
ensure
  puts "Always print this!"
end
