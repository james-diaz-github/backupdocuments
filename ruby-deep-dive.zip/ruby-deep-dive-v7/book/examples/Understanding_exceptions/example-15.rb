
ArgumentError: wrong number of arguments (1 for 2)
