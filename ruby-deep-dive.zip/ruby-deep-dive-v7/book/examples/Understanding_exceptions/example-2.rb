
shopping.rb:6:in 'buy_bread': No bread left! (RuntimeError)
	from shopping.rb:11:in 'go_shopping'
	from shopping.rb:14:in '<main>'
