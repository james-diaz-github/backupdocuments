
number = 1
"This is a string #{number}"
