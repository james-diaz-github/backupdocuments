
num = nil
num.say_hello

# NoMethodError: undefined method `say_hello' for nil:NilClass
