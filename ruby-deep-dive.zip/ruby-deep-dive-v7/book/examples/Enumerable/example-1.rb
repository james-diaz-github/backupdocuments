
p [10,20,30].inject { |total, num| total + num }
