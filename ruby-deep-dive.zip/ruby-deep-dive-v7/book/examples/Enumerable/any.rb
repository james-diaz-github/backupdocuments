
numbers = [5, 10, 20]
p numbers.any? { |n| n > 30 }
