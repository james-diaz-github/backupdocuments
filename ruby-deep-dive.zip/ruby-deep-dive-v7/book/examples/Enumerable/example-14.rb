
enum = [1,2,3,4].select
enum.class
# Enumerator
