
u.each { |u| u > 2 }
# [3,4]
