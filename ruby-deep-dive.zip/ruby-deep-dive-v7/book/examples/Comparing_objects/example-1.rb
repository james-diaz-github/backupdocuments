
10 > 5
# true

"abc" == "a"
# false
