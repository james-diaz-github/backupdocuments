
require 'json'

json = '{"water": 300, "oil": 200}'
hash = JSON.parse(json)
