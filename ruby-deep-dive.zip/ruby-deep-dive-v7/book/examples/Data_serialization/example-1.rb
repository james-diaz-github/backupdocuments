
require 'csv'

puts CSV.read("file.csv")
